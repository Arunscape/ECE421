mod calculator;
fn main() {}

#[cfg(test)]
mod question1;
#[cfg(test)]
mod question2;
#[cfg(test)]
mod question3;
#[cfg(test)]
mod question4;
