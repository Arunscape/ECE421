#!/bin/sh
cargo test -- --nocapture --test-threads=1
