mod question_1;
mod question_2;
mod question_3;

fn main() {
    println!("Question 1 output:");
    question_1::main();

    println!("\nQuesion 2 output:");
    question_2::main();

    println!("\nQuesion 3 output:");
    question_3::main();
}
