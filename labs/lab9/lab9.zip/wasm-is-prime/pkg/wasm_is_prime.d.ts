/* tslint:disable */
/* eslint-disable */
/**
*/
export function greet(): void;
/**
* @param {any} s 
*/
export function CheckPrime(s: any): void;
