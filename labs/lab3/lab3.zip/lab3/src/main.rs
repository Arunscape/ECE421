mod q1;
mod q2;

fn main() {
    q1::q1();
}
