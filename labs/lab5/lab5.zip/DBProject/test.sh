#!/bin/sh
cargo test -- --test-threads=1
